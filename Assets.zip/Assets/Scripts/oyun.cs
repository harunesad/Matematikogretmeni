﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class oyun : MonoBehaviour
{
    public oyun o;
    public Text soruadı, cevapa, cevapb, cevapc, cevapd, skor, zaman, sonuc;
    SOR s;
    public List<bool> sorulan;
    public int cevap, puan;
    public float sure;

    void Start()
    {
        sure = 45;
        s = GetComponent<SOR>();
        for (int i = 0; i < s.sorular.Count; i++)
        {
            sorulan.Add(false);
        }
        soruekleme();
    }
    void Update()
    {
        if (sure > 0)
        {
            sure -= Time.deltaTime;
            zaman.text = sure.ToString("00");
        }
        else
        {
            SceneManager.LoadScene("SONUC");
            o.oyunsonu();
        }
    }
    public void soruekleme()
    {
        for (int i = 0; i < sorulan.Count; i++)
        {

            if (sorulan[i] == false)
            {
                int sayi = Random.Range(0, sorulan.Count);
                if (sorulan[sayi] == false)
                {
                    sorulan[sayi] = true;

                    soruadı.text = s.sorular[sayi].soruadı;
                    cevapa.text = s.sorular[sayi].cevapa;
                    cevapb.text = s.sorular[sayi].cevapb;
                    cevapc.text = s.sorular[sayi].cevapc;
                    cevapd.text = s.sorular[sayi].cevapd;
                    cevap = s.sorular[sayi].cevap;
                }
                else
                {
                    soruekleme();
                }
                break;
            }
            if (i == sorulan.Count - 1)
            {
                SceneManager.LoadScene("SONUC");
                o.oyunsonu();
            }
        }
    }
    public void cevaplar(int rakam)
    {
        if (rakam == cevap)
        {
            puan += 10;
            skor.text = "PUAN:" + puan;
            soruekleme();
            sonuc.text = "DOĞRU CEVAP";
        }
        else
        {
            if (puan > 0)
            {
                puan -= 10;
                skor.text = "PUAN:" + puan;
                soruekleme();
                sonuc.text = "YANLIŞ CEVAP";
            }
            else
            {
                soruekleme();
                sonuc.text = "YANLIŞ CEVAP";
            }

        }
    }
    public void oyunsonu()
    {
        PlayerPrefs.SetInt("Puan:", puan);
       }

}
