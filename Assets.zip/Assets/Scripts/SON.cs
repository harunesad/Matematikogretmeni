﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SON : MonoBehaviour
{
    public oyun o;
    public Text skor,mesaj;
    public int puan;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
        skor.text = "PUANINIZ:" + PlayerPrefs.GetInt("Puan:");
        if (PlayerPrefs.GetInt("Puan:") <= 40 && PlayerPrefs.GetInt("Puan:") >= 0)
        {
            mesaj.text = "KÖTÜ";
        }
        else if(PlayerPrefs.GetInt("Puan:") <=80 && PlayerPrefs.GetInt("Puan:") > 40)
        {
            mesaj.text = "ZAYIF";
        }
        else if (PlayerPrefs.GetInt("Puan:") <= 120 && PlayerPrefs.GetInt("Puan:") > 80)
        {
            mesaj.text = "VASAT";
        }
        else if (PlayerPrefs.GetInt("Puan:") <= 160 && PlayerPrefs.GetInt("Puan:") > 120)
        {
            mesaj.text = "İYİ";
        }
        else if (PlayerPrefs.GetInt("Puan:") <= 200 && PlayerPrefs.GetInt("Puan:") > 160)
        {
            mesaj.text = "ÇOK İYİ";
        }
        else if (PlayerPrefs.GetInt("Puan:") <= 240 && PlayerPrefs.GetInt("Puan:") > 200)
        {
            mesaj.text = "MÜKEMMEL";
        }
        else if (PlayerPrefs.GetInt("Puan:") <= 280 && PlayerPrefs.GetInt("Puan:") > 240)
        {
            mesaj.text = "OLAĞANÜSTÜ";
        }
        else if (PlayerPrefs.GetInt("Puan:") <= 320 && PlayerPrefs.GetInt("Puan:") > 280)
        {
            mesaj.text = "DOĞAÜSTÜ";
        }
    }


}
