﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Toplama : MonoBehaviour
{
    public void toplama()
    {
        SceneManager.LoadScene("Toplama");
    }
    public void cikarma()
    {
        SceneManager.LoadScene("Çıkarma");
    }
    public void carpma()
    {
        SceneManager.LoadScene("Çarpma");
    }
    public void bolme()
    {
        SceneManager.LoadScene("Bölme");
    }
    public void cikis()
    {
        Application.Quit();
    }
    public void yeniden()
    {
        SceneManager.LoadScene("Anamenu");
    }
}
